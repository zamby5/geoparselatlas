// Worker adresini deploy sonrası buraya yaz:
window.API_BASE = "https://geoparsel-atlas.KULLANICI.workers.dev";
