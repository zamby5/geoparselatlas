/* Leaflet harita, TKGM parseli, Turf analizleri, OSM çevre, Tavily ihale, Groq rapor. */
(function () {
  const API = (window.API_BASE || "").replace(/\/$/, ""), $ = s => document.querySelector(s);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const say = h => $("#info").innerHTML = h;
  const map = L.map("map").setView([39, 35], 6);
  const sat = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", { maxZoom: 19, attribution: "Esri" }).addTo(map);
  const osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "© OpenStreetMap" });
  L.control.layers({ Uydu: sat, OSM: osm }).addTo(map);
  let layer = null, ctx = null;
  async function j(url, opt) {
    const r = await fetch(url, opt), t = await r.json().catch(() => null);
    if (!r.ok || !t || t.error) throw new Error(((t && t.error) || "HTTP " + r.status) + (t && t.ham ? " · " + t.ham : ""));
    return t;
  }
  map.on("click", e => run(e.latlng.lat, e.latlng.lng).catch(err => say("<b>Hata:</b> " + esc(err.message))));
  function poiMesafe(els, c) {
    const pt = turf.point(c), best = {};
    for (const e of els) {
      const t = e.tags || {}; let k = null;
      if (t.place) k = (t.place === "city" || t.place === "town") ? "ilce_sehir_merkezi" : "koy_mahalle";
      else if (t.highway === "motorway") k = "otoyol"; else if (t.highway) k = "ana_yol";
      else if (t.amenity === "hospital") k = "hastane"; else if (t.amenity === "school") k = "okul";
      if (!k) continue;
      let d = null;
      if (e.type === "node") d = turf.distance(pt, [e.lon, e.lat]);
      else if (e.geometry && e.geometry.length > 1) d = turf.pointToLineDistance(pt, turf.lineString(e.geometry.map(g => [g.lon, g.lat])));
      else if (e.bounds) d = turf.distance(pt, [(e.bounds.minlon + e.bounds.maxlon) / 2, (e.bounds.minlat + e.bounds.maxlat) / 2]);
      if (d != null && (!best[k] || d < best[k].km)) best[k] = { km: +d.toFixed(2), ad: t.name || "" };
    }
    return best;
  }
  async function run(lat, lon) {
    ctx = null; $("#rapor").textContent = ""; say("Parsel sorgulanıyor…");
    const r = await j(`${API}/pa/parsel?lat=${lat}&lon=${lon}`), f = r.type === "FeatureCollection" ? r.features && r.features[0] : r;
    if (!f || !f.geometry) throw new Error("TKGM bu noktada parsel döndürmedi");
    if (layer) layer.remove();
    layer = L.geoJSON(f, { style: { color: "#ffd400", weight: 3, fillOpacity: .2 } }).addTo(map); map.fitBounds(layer.getBounds(), { maxZoom: 17 });
    const c = turf.centerOfMass(f).geometry.coordinates, my = ctx = { f, c, alan: Math.round(turf.area(f)), stats: null, vs: null, poi: null, ihale: null };
    say("Arazi verisi (DEM) yükleniyor…");
    const dem = await GP.dem.load(API, c[1], c[0]);
    my.stats = GP.dem.parcelStats(dem, f); my.vs = GP.dem.viewshed(dem, c[1], c[0], 2); GP.view3d($("#v3d"), dem, f, my.vs);
    const props = Object.entries(f.properties || {}).filter(([, v]) => v != null && v !== "");
    const s = my.stats, v = my.vs;
    say(`<b>Alan (Turf):</b> ${my.alan.toLocaleString("tr-TR")} m²<br>` +
      (s ? `<b>Eğim:</b> ort. %${s.egim_ort_yuzde}, maks. %${s.egim_maks_yuzde} · <b>Yükseklik:</b> ${s.yukseklik_min_m}–${s.yukseklik_maks_m} m` : "Eğim hesaplanamadı") + `<br>` +
      (v ? `<b>Deniz manzarası:</b> ${v.gorunen_deniz_km2} km² görünür, ışınların %${v.denizi_goren_isin_yuzde}'i denize bakıyor, en uzak ${v.en_uzak_gorunen_deniz_km} km (etkili yarıçap ${v.etkili_yaricap_km} km)` : "Görüş hesaplanamadı") +
      `<table>${props.map(([k, x]) => `<tr><td>${esc(k)}</td><td>${esc(typeof x === "object" ? JSON.stringify(x) : x)}</td></tr>`).join("")}</table>`);
    const q = props.filter(([k]) => /^(il|ilce|mahalle)(ad|adi)?$/i.test(k)).map(([, x]) => x).join(" "); if (q) $("#q").value = q;
    $("#poi").textContent = "Çevre verisi (OSM)…";
    j(`${API}/pa/poi?lat=${c[1]}&lon=${c[0]}&km=15`).then(o => { if (ctx !== my) return; my.poi = poiMesafe(o.elements, c);
      $("#poi").innerHTML = "<b>Kuş uçuşu en yakın (OSM, 15 km):</b><br>" + (Object.keys(my.poi).length ? Object.entries(my.poi).map(([k, x]) => `${k}: ${x.km} km ${esc(x.ad)}`).join("<br>") : "kayıt yok");
    }).catch(e => { $("#poi").textContent = "OSM hatası: " + e.message; });
    if (q) ihale();
  }
  async function ihale() {
    const q = $("#q").value.trim(); if (!q) return; $("#ih").textContent = "Aranıyor…"; const my = ctx;
    try { const r = await j(`${API}/pa/ihale?q=${encodeURIComponent(q)}`); if (my) my.ihale = r.sonuclar;
      $("#ih").innerHTML = r.sonuclar.length ? r.sonuclar.map(x => `<p><a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.baslik || x.url)}</a><br><small>${esc(x.ozet)}</small></p>`).join("") : "Sonuç yok";
    } catch (e) { $("#ih").textContent = "İhale araması: " + e.message; }
  }
  $("#ihb").onclick = ihale;
  $("#rb").onclick = async () => {
    if (!ctx) return say("Önce bir parsel seç."); const my = ctx, v = my.vs && { ...my.vs }; if (v) delete v._rays;
    $("#rapor").textContent = "Rapor hazırlanıyor…";
    const data = { parsel: { alan_m2_turf: my.alan, tkgm_ozellikleri: my.f.properties || {} }, arazi: my.stats, manzara: v, cevre_kus_ucusu_km: my.poi, ihale_arama_sonuclari: my.ihale,
      saglanmayan_veriler: ["resmi imar durumu", "heyelan/jeolojik risk", "orman/koruma sınırı", "emsal satış fiyatları", "yol mesafesi (yalnızca kuş uçuşu var)"] };
    try { $("#rapor").textContent = (await j(`${API}/pa/ai`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ data }) })).rapor; }
    catch (e) { $("#rapor").textContent = "Rapor hatası: " + e.message; }
  };
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js");
})();
