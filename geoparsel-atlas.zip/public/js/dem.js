/* DEM: Terrarium karoları → yükseklik, eğim, görüş (viewshed). Çözünürlük ~29 m (z12); yüzey modeli (DSM). */
(function (G) {
  const Z = 12, RE = 6371000, M = 111320;
  const tile = (lat, lon) => { const n = 2 ** Z, r = lat * Math.PI / 180; return { x: (lon + 180) / 360 * n, y: (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n }; };
  async function tileData(api, x, y) {
    const r = await fetch(`${api}/pa/dem?z=${Z}&x=${x}&y=${y}`);
    if (!r.ok) throw new Error("DEM karosu alınamadı: HTTP " + r.status);
    const b = await createImageBitmap(await r.blob(), { colorSpaceConversion: "none" });
    const c = document.createElement("canvas"); c.width = c.height = 256;
    const g = c.getContext("2d", { willReadFrequently: true }); g.drawImage(b, 0, 0);
    return g.getImageData(0, 0, 256, 256).data;
  }
  async function load(api, lat, lon) {
    const t = tile(lat, lon), cx = Math.floor(t.x), cy = Math.floor(t.y), N = 768, E = new Float32Array(N * N);
    await Promise.all([-1, 0, 1].flatMap(dy => [-1, 0, 1].map(async dx => {
      const d = await tileData(api, cx + dx, cy + dy);
      for (let j = 0; j < 256; j++) for (let i = 0; i < 256; i++) { const k = (j * 256 + i) * 4; E[((dy + 1) * 256 + j) * N + (dx + 1) * 256 + i] = d[k] * 256 + d[k + 1] + d[k + 2] / 256 - 32768; }
    })));
    const x0 = (cx - 1) * 256, y0 = (cy - 1) * 256;
    const sample = (la, lo) => {
      const p = tile(la, lo), fx = p.x * 256 - x0, fy = p.y * 256 - y0;
      if (fx < 0 || fy < 0 || fx >= N - 1 || fy >= N - 1) return null;
      const i = Math.floor(fx), j = Math.floor(fy), a = fx - i, b = fy - j;
      return E[j * N + i] * (1 - a) * (1 - b) + E[j * N + i + 1] * a * (1 - b) + E[(j + 1) * N + i] * (1 - a) * b + E[(j + 1) * N + i + 1] * a * b;
    };
    return { sample, mpp: la => 40075016.686 * Math.cos(la * Math.PI / 180) / (256 * 2 ** Z) };
  }
  function slope(dem, lat, lon) { // merkezi fark, 30 m
    const d = 30, dy = d / M, dx = dy / Math.cos(lat * Math.PI / 180);
    const e = dem.sample(lat, lon + dx), w = dem.sample(lat, lon - dx), n = dem.sample(lat + dy, lon), s = dem.sample(lat - dy, lon);
    return [e, w, n, s].some(v => v == null) ? null : 100 * Math.hypot((e - w) / (2 * d), (n - s) / (2 * d));
  }
  function parcelStats(dem, f) {
    const b = turf.bbox(f), c = turf.centerOfMass(f).geometry.coordinates, S = [], H = [];
    const sy = 25 / M, sx = sy / Math.cos(c[1] * Math.PI / 180);
    for (let y = b[1]; y <= b[3]; y += sy) for (let x = b[0]; x <= b[2]; x += sx) if (turf.booleanPointInPolygon([x, y], f)) {
      const s = slope(dem, y, x), z = dem.sample(y, x); if (s != null && z != null) { S.push(s); H.push(z); }
    }
    if (!S.length) { const s = slope(dem, c[1], c[0]), z = dem.sample(c[1], c[0]); if (s != null && z != null) { S.push(s); H.push(z); } }
    if (!S.length) return null;
    const avg = a => a.reduce((p, q) => p + q, 0) / a.length;
    return { ornek_sayisi: S.length, egim_ort_yuzde: +avg(S).toFixed(1), egim_maks_yuzde: +Math.max(...S).toFixed(1), yukseklik_min_m: Math.round(Math.min(...H)), yukseklik_maks_m: Math.round(Math.max(...H)), yukseklik_ort_m: Math.round(avg(H)), yontem: "DEM ~29 m, merkezi fark, 25 m örnekleme" };
  }
  function viewshed(dem, lat, lon, eye) { // ışın izleme: görüş açısı artan hücreler görünür; dünya eğriliği düzeltmeli
    const z0 = dem.sample(lat, lon); if (z0 == null) return null;
    const R = 10000, st = dem.mpp(lat), dth = 2 * Math.PI / 180, eyeH = z0 + eye, kx = M * Math.cos(lat * Math.PI / 180), rays = [];
    let area = 0, far = 0, cover = 0, reach = Infinity;
    for (let a = 0; a < 180; a++) {
      const th = a * dth, cs = Math.cos(th), sn = Math.sin(th); let mx = -Infinity, farSea = 0, last = 0;
      for (let d = st; d <= R; d += st) {
        const e = dem.sample(lat + d * cs / M, lon + d * sn / kx); if (e == null) break; last = d;
        const ang = (e - d * d / (2 * RE) - eyeH) / d;
        if (ang >= mx) { mx = ang; if (e <= 0) { area += d * dth * st; farSea = d; } }
      }
      reach = Math.min(reach, last); if (farSea) { cover++; far = Math.max(far, farSea); } rays.push({ az: a * 2, farSea });
    }
    return { goz_yuksekligi_m: eye, etkili_yaricap_km: +(reach / 1000).toFixed(1), denizi_goren_isin_yuzde: +(cover / 180 * 100).toFixed(0), gorunen_deniz_km2: +(area / 1e6).toFixed(2), en_uzak_gorunen_deniz_km: +(far / 1000).toFixed(1),
      yontem: "180 ışın; DEM'de yükseklik ≤ 0 m hücre deniz sayılır (kıyı ovası/göl yanılgısı olabilir); DSM bina/ağaç içerir", _rays: rays };
  }
  G.dem = { load, parcelStats, viewshed };
})(window.GP = window.GP || {});
