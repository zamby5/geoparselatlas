/* Three.js: DEM arazi ağı, parsel prizması/çerçevesi ve görünür deniz ışınları. */
(function (G) {
  let R = null, raf = 0;
  G.view3d = function (el, dem, f, vs) {
    const c = turf.centerOfMass(f).geometry.coordinates, lat0 = c[1], lon0 = c[0], ky = 111320, kx = ky * Math.cos(lat0 * Math.PI / 180), EX = 1.5, half = 5000, n = 200;
    cancelAnimationFrame(raf); if (R) { R.dispose(); el.innerHTML = ""; }
    const W = el.clientWidth, Hh = el.clientHeight, sc = new THREE.Scene(); sc.background = new THREE.Color(0x0b1d16);
    const cam = new THREE.PerspectiveCamera(50, W / Hh, 10, 60000); R = new THREE.WebGLRenderer({ antialias: true }); R.setSize(W, Hh); el.appendChild(R.domElement);
    const g = new THREE.PlaneGeometry(2 * half, 2 * half, n, n), p = g.attributes.position, col = new Float32Array(p.count * 3), hs = [];
    let hmax = 1;
    for (let k = 0; k < p.count; k++) { const h = dem.sample(lat0 + p.getY(k) / ky, lon0 + p.getX(k) / kx); hs.push(h == null ? 0 : h); if (h > hmax) hmax = h; }
    hs.forEach((h, k) => { p.setZ(k, h * EX); const t = Math.min(1, Math.max(0, h / hmax)); col.set(h <= 0 ? [.1, .3, .6] : [.2 + .5 * t, .5 + .1 * t, .2 + .3 * t], k * 3); });
    g.setAttribute("color", new THREE.BufferAttribute(col, 3)); g.rotateX(-Math.PI / 2); g.computeVertexNormals();
    sc.add(new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true })), new THREE.AmbientLight(0xffffff, .6));
    const dl = new THREE.DirectionalLight(0xffffff, .8); dl.position.set(1, 2, 1); sc.add(dl);
    const z0 = dem.sample(lat0, lon0) || 0, ring = (f.geometry.type === "Polygon" ? f.geometry.coordinates[0] : f.geometry.coordinates[0][0]).map(([lo, la]) => [(lo - lon0) * kx, (la - lat0) * ky]);
    const pg = new THREE.ExtrudeGeometry(new THREE.Shape(ring.map(([x, y]) => new THREE.Vector2(x, y))), { depth: 60, bevelEnabled: false }); pg.rotateX(-Math.PI / 2); pg.translate(0, z0 * EX - 20, 0);
    sc.add(new THREE.Mesh(pg, new THREE.MeshBasicMaterial({ color: 0xffd400, transparent: true, opacity: .55 })));
    sc.add(new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(ring.map(([x, y]) => new THREE.Vector3(x, (dem.sample(lat0 + y / ky, lon0 + x / kx) || z0) * EX + 4, -y))), new THREE.LineBasicMaterial({ color: 0xffd400 })));
    if (vs) { const v = []; vs._rays.filter(r => r.farSea).forEach(r => { const th = r.az * Math.PI / 180, d = Math.min(r.farSea, half); v.push(0, (z0 + vs.goz_yuksekligi_m) * EX, 0, d * Math.sin(th), 0, -d * Math.cos(th)); });
      sc.add(new THREE.LineSegments(new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute(v, 3)), new THREE.LineBasicMaterial({ color: 0x00e5ff }))); }
    cam.position.set(0, z0 * EX + 1200, 2200); const oc = new THREE.OrbitControls(cam, R.domElement); oc.target.set(0, z0 * EX, 0); oc.update();
    (function loop() { raf = requestAnimationFrame(loop); R.render(sc, cam); })();
  };
})(window.GP = window.GP || {});
