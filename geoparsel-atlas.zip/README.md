# GeoParsel Atlas
**Arayüz (GitHub Pages):** `public/`. `public/config.js` → `API_BASE` = Worker adresi.
**API:** `src/geoparsel.js` yalnızca `/pa/*` işler: parsel, parsel-ada, dem, poi (Overpass), ihale (Tavily), ai (Groq).
## Mevcut Worker'a ekleme
`src/geoparsel.js`'i kopyala; `fetch` başına: `const pa = await handleGeoParsel(request, env); if (pa) return pa;`
Secret'lar: `TAVILY_API_KEY` (ya da `TAVILY_KEY`), `GROQ_API_KEY` (ya da `GROQ_KEY`). İsteğe bağlı: `GROQ_MODEL`, `ALLOWED_ORIGINS` (virgülle; varsayılan https://zamby5.github.io).
## İlk test
Parsele dokun; hata kutusundaki "ham" TKGM'nin gerçek yanıtıdır.
