// GeoParsel Atlas – Cloudflare Worker modülü. Yalnızca /pa/* işler; diğer istekler için null döner.
// TKGM: parsel/{mahalleId}/{ada}/{parsel} kaynaklarda doğrulandı; parsel/{lat}/{lon} CANLI TEST EDİLMEDİ.
const TK = "https://cbsservis.tkgm.gov.tr/megsiswebapi.v3/api/";
const H = { Accept: "application/json", "User-Agent": "Mozilla/5.0", Referer: "https://parselsorgu.tkgm.gov.tr/" };
const SYS = "Sen gayrimenkul yatırım analisti ve GIS uzmanısın. YALNIZCA kullanıcı mesajındaki JSON verisini kullan. JSON'da olmayan hiçbir sayı, fiyat, imar/yasal bilgi UYDURMA; eksik her şey için 'veri yok' yaz. 'saglanmayan_veriler' listesindekileri 'doğrulanmadı' diye belirt. İhale bulgularında yalnızca verilen başlık/özet/URL'yi kullan, kaynak URL'yi yaz. Biçim: 1) Özet 2) Arazi ve eğim 3) Erişim ve çevre 4) Manzara 5) İhale/piyasa bulguları 6) Riskler ve doğrulanması gerekenler 7) Sonuç. Türkçe, kısa, maddeli. Son satır: 'Yatırım tavsiyesi değildir.'";
async function up(url, init) {
  const r = await fetch(url, init), t = await r.text();
  let j = null; try { j = JSON.parse(t); } catch {}
  return { status: r.status, j, t: t.slice(0, 300) };
}
export async function handleGeoParsel(req, env) {
  const u = new URL(req.url), p = u.pathname, q = u.searchParams;
  if (!p.startsWith("/pa/")) return null;
  const allowed = (env.ALLOWED_ORIGINS || "https://zamby5.github.io").split(",").map(s => s.trim());
  const o = req.headers.get("Origin") || "";
  const cors = { "access-control-allow-origin": allowed.includes(o) ? o : allowed[0], "access-control-allow-methods": "GET,POST,OPTIONS", "access-control-allow-headers": "content-type", vary: "Origin" };
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  const J = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { ...cors, "content-type": "application/json; charset=utf-8" } });
  try {
    if (p === "/pa/parsel") {
      const a = Number(q.get("lat")), b = Number(q.get("lon"));
      if (!isFinite(a) || !isFinite(b)) return J({ error: "lat/lon gerekli" }, 400);
      const r = await up(`${TK}parsel/${a}/${b}/`, { headers: H });
      return r.j ? J(r.j) : J({ error: "TKGM geçerli yanıt vermedi", status: r.status, ham: r.t }, 502);
    }
    if (p === "/pa/parsel-ada") {
      const [m, a, s] = ["mahalle", "ada", "parsel"].map(k => q.get(k) || "");
      if (![m, a, s].every(v => /^\d+$/.test(v))) return J({ error: "mahalle/ada/parsel sayı olmalı" }, 400);
      const r = await up(`${TK}parsel/${m}/${a}/${s}`, { headers: H });
      return r.j ? J(r.j) : J({ error: "TKGM geçerli yanıt vermedi", status: r.status, ham: r.t }, 502);
    }
    if (p === "/pa/dem") { // Terrarium karoları: canvas için aynı kökenden (CORS güvenli) sunulur
      const [z, x, y] = ["z", "x", "y"].map(k => q.get(k) || "");
      if (![z, x, y].every(v => /^\d{1,8}$/.test(v))) return J({ error: "z/x/y sayı olmalı" }, 400);
      const r = await fetch(`https://s3.amazonaws.com/elevation-tiles-prod/terrarium/${z}/${x}/${y}.png`, { cf: { cacheTtl: 604800, cacheEverything: true } });
      return new Response(r.body, { status: r.status, headers: { ...cors, "content-type": "image/png", "cache-control": "public, max-age=604800" } });
    }
    if (p === "/pa/poi") {
      const lat = Number(q.get("lat")), lon = Number(q.get("lon")), km = Math.min(20, Math.max(1, Number(q.get("km")) || 15));
      if (!isFinite(lat) || !isFinite(lon)) return J({ error: "lat/lon gerekli" }, 400);
      const a = `(around:${km * 1000},${lat},${lon})`;
      const Q = `[out:json][timeout:25];(node${a}[place~"^(city|town|village|hamlet)$"];way${a}[highway~"^(motorway|trunk|primary)$"];nwr${a}[amenity~"^(hospital|school)$"];);out geom 250;`;
      const r = await up("https://overpass-api.de/api/interpreter", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "data=" + encodeURIComponent(Q) });
      return r.j ? J({ elements: r.j.elements || [] }) : J({ error: "Overpass yanıt vermedi", status: r.status, ham: r.t }, 502);
    }
    if (p === "/pa/ihale") {
      const s = (q.get("q") || "").trim().slice(0, 80), key = env.TAVILY_API_KEY || env.TAVILY_KEY;
      if (!s) return J({ error: "q gerekli" }, 400);
      if (!key) return J({ error: "Tavily anahtarı tanımlı değil (TAVILY_API_KEY)" }, 500);
      const r = await up("https://api.tavily.com/search", { method: "POST", headers: { "content-type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({ query: `${s} milli emlak satış ihale ilanı arsa tarla`, search_depth: "basic", max_results: 6, include_domains: ["milliemlak.gov.tr"] }) });
      if (!r.j?.results) return J({ error: "Tavily hata", status: r.status, ham: r.t }, 502);
      return J({ sonuclar: r.j.results.map(x => ({ baslik: x.title, url: x.url, ozet: (x.content || "").slice(0, 300) })) });
    }
    if (p === "/pa/ai") {
      if (req.method !== "POST") return J({ error: "POST gerekli" }, 405);
      const key = env.GROQ_API_KEY || env.GROQ_KEY;
      if (!key) return J({ error: "GROQ_API_KEY tanımlı değil" }, 500);
      const body = await req.text();
      if (body.length > 30000) return J({ error: "veri çok büyük" }, 413);
      let d; try { d = JSON.parse(body).data; } catch { return J({ error: "geçersiz JSON" }, 400); }
      const r = await up("https://api.groq.com/openai/v1/chat/completions", { method: "POST", headers: { "content-type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({ model: env.GROQ_MODEL || "llama-3.3-70b-versatile", temperature: 0.1, max_tokens: 1500, messages: [{ role: "system", content: SYS }, { role: "user", content: "VERİ (JSON):\n" + JSON.stringify(d) }] }) });
      const t = r.j?.choices?.[0]?.message?.content;
      return t ? J({ rapor: t }) : J({ error: "Groq hata", status: r.status, ham: r.t }, 502);
    }
  } catch (e) { return J({ error: String(e) }, 500); }
  return J({ error: "yok" }, 404);
}
