import { handleGeoParsel } from "./geoparsel.js";
export default { async fetch(req, env) { return (await handleGeoParsel(req, env)) || new Response("yok", { status: 404 }); } };
